

import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="CyrilMYSQL2023!",
    database="gestionstudent"
)
